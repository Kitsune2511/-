import { useEffect, useState, useRef } from 'react'
import DesignComponent from '@/imports/ГлавнаяСтраница/index'

const DESIGN_W = 1440
const DESIGN_H = 3000

const MARQUEE_1 =
  'КРЕАТОР  ★  СТРАТЕГ  ★  МЕНЕДЖЕР МАРКЕТПЛЕЙСОВ  ★  КРЕАТОР  ★  СТРАТЕГ  ★  МЕНЕДЖЕР МАРКЕТПЛЕЙСОВ  ★  '
const MARQUEE_2 =
  'БРЕНДИНГ  ★  СТРАТЕГИЯ  ★  ДИЗАЙН  ★  АНАЛИТИКА  ★  БРЕНДИНГ  ★  СТРАТЕГИЯ  ★  ДИЗАЙН  ★  АНАЛИТИКА  ★  '

const marqueeTextStyle: React.CSSProperties = {
  fontFamily: "'Arima Madurai', sans-serif",
  fontWeight: 700,
  fontSize: '48px',
  color: '#000',
  textTransform: 'uppercase',
  letterSpacing: '0.02em',
  paddingRight: '80px',
  whiteSpace: 'nowrap',
}

function MarqueeStrip({
  text,
  top,
  left = '-5.62px',
  width = '1452px',
  height = '119px',
  rotate,
}: {
  text: string
  top: string
  left?: string
  width?: string
  height?: string
  rotate: string
}) {
  return (
    <div
      role="marquee"
      aria-label={text}
      style={{
        position: 'absolute',
        top,
        left,
        width,
        height,
        transform: rotate,
        transformOrigin: 'center center',
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'center',
        backgroundColor: '#D4FF3F',
        border: '3px solid #000',
        zIndex: 10,
        cursor: 'default',
      }}
    >
      {/* Scrolling track — two copies for seamless loop */}
      <div
        className="marquee-track"
        style={{ display: 'flex', alignItems: 'center', flexShrink: 0 }}
      >
        <span style={marqueeTextStyle}>{text}</span>
        <span style={marqueeTextStyle} aria-hidden="true">
          {text}
        </span>
      </div>
    </div>
  )
}

export default function App() {
  const [scale, setScale] = useState(1)
  const outerRef = useRef<HTMLDivElement>(null)

  // Update scale on resize
  useEffect(() => {
    const calc = () => {
      const vw = document.documentElement.clientWidth
      setScale(Math.min(1, vw / DESIGN_W))
    }
    calc()
    window.addEventListener('resize', calc)
    return () => window.removeEventListener('resize', calc)
  }, [])

  // Scroll-reveal: observe sections inside the inner canvas
  useEffect(() => {
    const inner = outerRef.current
    if (!inner) return
    const revealEls = inner.querySelectorAll<HTMLElement>('[data-reveal]')
    if (!revealEls.length) return
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            ;(e.target as HTMLElement).style.opacity = '1'
            ;(e.target as HTMLElement).style.transform = 'translateY(0)'
            obs.unobserve(e.target)
          }
        })
      },
      { threshold: 0.1 }
    )
    revealEls.forEach((el) => obs.observe(el))
    return () => obs.disconnect()
  }, [scale])

  const scaledH = Math.round(DESIGN_H * scale)

  return (
    <div
      style={{
        width: '100%',
        overflowX: 'hidden',
        background: '#ff7a01',
      }}
    >
      {/* Centered at max 1440px; on wide viewports the design stays native-size */}
      <div
        style={{
          maxWidth: `${DESIGN_W}px`,
          margin: '0 auto',
          position: 'relative',
          height: `${scaledH}px`,
          overflow: 'hidden',
        }}
      >
        {/* Inner: 1440×3000 canvas, scaled to fit viewport */}
        <div
          ref={outerRef}
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: `${DESIGN_W}px`,
            height: `${DESIGN_H}px`,
            transformOrigin: 'top left',
            transform: `scale(${scale})`,
          }}
        >
          {/* ── Figma design ── */}
          <DesignComponent />

          {/* ── Marquee strip 1: top yellow-green strip near nav ────────────
              Original strip SVG: top≈126.5px, left≈-5.62px, 1452×119px, rotate(-2.84deg)
          ───────────────────────────────────────────────────────────────── */}
          <MarqueeStrip
            text={MARQUEE_1}
            top="126.51px"
            left="-5.62px"
            rotate="rotate(-2.84deg)"
          />

          {/* ── Marquee strip 2: skills section yellow-green strip ───────────
              Desktop2 starts at top=1267px.
              Strip is at top=273.5px within Desktop2 → absolute top≈1540.5px
              Original rotation was effectively +2.84deg after double-flip
          ───────────────────────────────────────────────────────────────── */}
          <MarqueeStrip
            text={MARQUEE_2}
            top="1540.5px"
            left="-5.63px"
            rotate="rotate(2.84deg)"
          />
        </div>
      </div>
    </div>
  )
}
